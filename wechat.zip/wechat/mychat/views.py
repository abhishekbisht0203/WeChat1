from django.shortcuts import render
from django.contrib.auth.models import User  
from .models import *
from django.contrib.auth.decorators import login_required


# Create your views here.
def index(request):
    return render(request, 'index.html')

def login_user(request):
    return render(request, 'account/login.html')

@login_required
def chat(request, id):
    all_chats = Chat.objects.filter(sender=request.user, receiver=User.objects.get(id=id)) | Chat.objects.filter(receiver=request.user, sender=User.objects.get(id=id))    
    all_users = User.objects.exclude(username= request.user.username)
    return render(request, 'chat.html', {'all_users': all_users}, {'all_chats': all_chats})

@login_required
def friends(request):
    all_users = User.objects.exclude(username= request.user.username)
    return render(request, 'friends.html', {'all_users': all_users})